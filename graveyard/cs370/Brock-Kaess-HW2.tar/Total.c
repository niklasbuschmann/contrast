#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int sum(int num){
    for(int i = num - 1; i > 0; i--){
        num += i;
    }
    return num;
}

int main(int argc, char *argv[]){
    int pid = getpid(), rtn = sum(atoi(argv[1]));
    printf("Total[%d] : Sum = %d\n", pid, rtn);
    return rtn;
}
README
======
This is a simple practical which in itself contains another practical! Files in the tar include:
-scheduler.py
-Makefile
-README.txt (this file)
-hard work and tears with a bit of love

QUESTIONS
=========

1. What is the other name for Shortest Job First Preemptive Algorithm?
    Priority Scheduling

2. What are the 5 different states a process can be in scheduling 
(Look into process state diagram)?
    New, Ready, Running, Waiting, End

3. Shortest Job First is like Priority Scheduling with the priority 
based on ______ of the process?
    Burst length

4. ________ effect is the primary disadvantage of First Come First 
Serve Scheduling algorithm.
    Convoy

5. How does Multi Level Feedback queue prevent starvation of processes 
that waits too long in lower priority queue?
    It has age priority as a factor
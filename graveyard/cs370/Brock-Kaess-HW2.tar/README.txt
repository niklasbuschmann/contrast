README
======
This is a simple practical which in itself contains another practical! Files in the tar include:
-Starter.c 
-Fibb.c 
-Prime.c 
-Total.c 
-Makefile
-HW2README.txt (this file)
-hard work and tears with a bit of love

QUESTIONS
=========

1. How many of the least significant bits of the status does WEXITSTATUS return?
    8.
2. Which header file has to be included to use the WEXITSTATUS?
    #include <sys/wait.h>
3. What is the return value for the fork() in a child process?
    0
4. Give a reason for the fork() to fail?
    Lack of memory it can use.
5. In the program written by you, are we doing a sequential processing or a concurrent processing 
    with respect to the child processes? Sequential processing is when only one of the child
    processes is running at one time, and concurrent processing is when more than one child
    process can be running at the same time.
        I'm ding sequential processing.
6. Do you Observe any anomalies in the output from child process and the output from parent
    process. Provide a reason for that observation.
        I don't see any anomalies.
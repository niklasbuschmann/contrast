1. What is a docker container? [2]
- A small platform, both open and secure, that simplifies 
    the production and distribution of apps which can be ran
    on linux/windows servers. A docker consists of images 
    and containers. The container can run based of information
    from an image which is a sort of application.

2. What is the difference between a container and a virtual machine? [2]
- A VM needs an OS inside of an existing OS. However a docker just needs
    an image like the example UBuntu with Node.js and Application Code
    which can be ran inside a container. More technically, at a system
    level breakdown, the difference is an OS on top of apps, bins/libs, 
    and the host OS, a VM also needs a hypervisor and Guest OS's. In 
    contrast the docker everything but the hyperviser and Guest OS's, though
    with the addition of the Docker Engine.

3. What is the purpose of a Dockerfile? [2]
- To create a docker image

4. What is the purpose of a requirements.txt file? [2]
- It captures any and all app dependencies

5. What is the purpose of a docker-compose.yml file? [2]
- Helps when you have multiple containers and you want to build the images for
    all the containers and runs the containers for ALL the dock containers.

6. What is the difference between a docker image and docker container? [2]
- A docker image contains the actual implementation of some application Code
    and a container is a contained environment in which the image can run/execute.

7. What command can be used to create an image from a Dockerfile? [2]
- docker build <path>

8. What command will start a docker container? [2]
- docker container run -d -p <port>:<port> <image ID>

9. What command will stop a docker container? [2]
- docker container stop node(or <container id>)

10. What command will remove a docker container? Image? [5]
- docker container rm node (or <container id>)

11. What command will list all running docker containers? all containers? [5]
- docker container ps
- docker container ps --all

12. What command will list all docker images?
- docker images

13. What command do you use to deploy docker containers using information 
in the docker-compose.yml file? [2]
-  docker-compose up

14. How can you specify in the docker-compose.yml file that you want docker 
containers to use the hosts network? [5]
- network_mode: host

15. How can you specify in the docker-compose.yml file where the Dockerfile 
for a particular container is found? [5]
- /<path>

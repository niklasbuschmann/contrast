# # Does a GET request on http://localhost:5000 to get data from 
# # server and prints the message received.
import requests

if __name__ == "__main__":
    x = requests.get('http://localhost:5000')
    print(x.text)
    exit(0)
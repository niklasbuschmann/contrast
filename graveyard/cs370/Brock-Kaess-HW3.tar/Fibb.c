#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <ctype.h>
#include <stdlib.h>

/*
    Takes an int and returns the fibbonacci sequence for it
*/
int fibBrooo(int num){
    int t1 = 0, t2 = 1, nextTerm = -1, rtn = -1;
    for (int i = 0; i < num; i++) {
        printf("%d", t1);
        if(i < num - 1){
            printf(", ");
        } else{
            rtn = t1;
        }
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
    printf("\n");
    return rtn;
}

int main(int argc, char *argv[]){
    if(argc < 2){
        fprintf(stderr, "%s -> ERROR: I need more arguments\n", argv[0]);
        exit(1);
    }
    char shm_Fibb[] = "Shared_Mem_Fib";  // Name of shared mem seg
    int shm_fd_Fibb = shm_open(shm_Fibb, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    int SIZE = 32;  // Byte size
    void *shmPtrFibb = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd_Fibb, 0); // Mapping the new mem seg
    

    int pid = getpid();
    printf("Fibb[%d]: Number of terms in fibonacii series is %d\n", pid, atoi(argv[2]));
    printf("Fibb[%d]: The first %d numbers of the Fibonacci sequence are: \n", pid, atoi(argv[2]));
    int rtn = fibBrooo(atoi(argv[2]));
    sprintf(shmPtrFibb, "%d", rtn);
    shm_unlink(shm_Fibb);
    return rtn;
}

public class Consumer extends java.lang.Thread {
	// Necessary variables and object declaration
	Buffer buff;	// Copy of the instance of the buffer to access in common with others
	int count;		// Number of elements the consumer should consume
	int id;			// ID which is number of the consumer thread (first producer = 1, second = 2...)
	int sum = 0;	// checksum of the items it has consumed.
	int data;		// Data value pulled from buffer.
	int location;	// Location of Buffer consumed.
	int time;		// Time for print statement
	

	public Consumer(Buffer buff, int count, int id) {
		// Assign values to the variables
		this.buff = buff;
		this.count = count;
		this.id = id;
	}
	
	// Returns the checksum of the items it has consumed.
	public int getCheckSum(){ return sum; }

	// Returns the value of work/count of things done
	public int getWork(){ return count; }

	@Override
	public void run() {
		/* 
		* Your code goes in here
		*/
		synchronized(buff) {
			for(int i = 0; i < count; i++) {
				data = buff.pop();
				sum += data;
				location = (buff.head - 1) % buff.capacity;
				System.out.print(this.toString());
				System.out.flush();
			}
		}
	}
	
	// When a consumer successfully removes an item from the buffer it should print the location of removal 
	// and time when removal occurs with microsecond resolution, using this format:
	// Consumer 3 consumed 62 from index 0 at time 2021-03-16 15:26:50.946821
	public String toString() {
		String s = String.format("\033[0;4mConsumer %3d consumed %3d from index %d at time\033[0;0m %s\n", id, data, location, Coordinator.getTime());
		return s;
	}
}

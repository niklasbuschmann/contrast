#include <stdio.h>
#include <stdlib.h>

/*int main(){
 int x = 90%95;
 printf("%d",x);
 printf("%c",get_arr_val(x));

 return 0;
}*/
 int maxCount, maxIteration;

 int get_iteration_no(int rand){
  return ((rand % (100 - 50)) + 50);
 }

 int get_arr_size(int rand){
  return ((rand % (150 - 100) + 100));
 }

 char get_arr_val(int rand){
  return (char)((rand % (91 - 65) + 65));
 }

/* TODO: In this auxiliary function the number of vowels 
   and consonants in the array is found, and so is the 
   ratio vowels/consonants. It also compares the maximum 
   number of vowels in all the iterations so far, which is
   the value stored in the address pointed by maxCountPointer. 
   If the maximum number of vowels found so far is less than the 
   count of the vowels in the current iteration, the value at 
   the address pointed by maxCountPointer is changed to count.
 */
 float ratio(char *a, int size, int *maxCountPointer){
     float vowels = 0, cons = 0;

     for (int i = 0; i < size; i++){
         //Check for vowel/cons counter
         if(a[i] == 'A' || a[i] == 'E' || 
            a[i] == 'I' || a[i] == 'O' || a[i] == 'U'){
             vowels++;
         } else{
             cons++;
         }

     }
     //Update maxCountPointer if new max
     if(*maxCountPointer < vowels){
         *maxCountPointer = vowels;
     }
     //printf("Vowels: %f, Cons: %f\n", vowels, cons);	
     return vowels/cons;
 }

 double get_running_ratio(){
     //Step 2
     int maxCount = 0, maxIteration = 0, 
     iterationNo = get_iteration_no(rand());
     double currentRat = 0, avg;
     printf("[Executor]: Number of iterations is %d\n", iterationNo);
     //Steps 3-8
     for (int i = 0; i < iterationNo; i++){
         //Step 3
         int aSize = get_arr_size(rand());
         char *a = (char*)malloc(aSize * sizeof(char));
         // Step 4
         for (int j = 0; j < aSize; j++){
             a[j] = get_arr_val(rand());
         }
         //Step 5
         int tempMaxCount = maxCount;
         currentRat += ratio(a,aSize,&maxCount);
         //Step 6
         if(tempMaxCount != maxCount){
             maxIteration = i;
         }

         free(a);
     }
     //Step 7
     avg = (double) currentRat/iterationNo;
     printf("[Executor]: Iteration with maximum vowel count is %d\n", maxIteration + 1);
  return (double) avg;
 }

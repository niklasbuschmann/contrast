import java.time.Instant;
import java.time.Clock;
import java.time.Duration;

class Coordinator {
	public static void main(String[] args) {
		/* 
		 * Your code goes in here
		 */
		// Necessary variables declared and initialized
		int bufferSize = Integer.parseInt(args[0]);	// Number of elements in buffer/buffer size
		int work = Integer.parseInt(args[1]);		// Number of items to be produced and consumed
		int consumers = Integer.parseInt(args[2]);	// Number of consumers (between 1 and 3)
		int producers = Integer.parseInt(args[3]);	// Number of producers (between 1 and 3)
		int seed = Integer.parseInt(args[4]);		// The seed for random number generation in producer and consumer classes
		// Divide out the work evenly for the producers
		int smallerP = 0;	// Smaller work portion for producers
		int largerP = work;	// Larger portion for producers
		if(largerP % producers != 0) {
			smallerP = largerP / producers; // Smaller work remainder after work divided evenly
			largerP = largerP / (producers - smallerP);
		}else {
			largerP /= producers;
		}
		// Divide out the work evenly for the consumers
		int smallerC = 0;	// Smaller work portion for consumers
		int largerC = work;	// Larger portion for consumers
		if(largerC % consumers != 0) {
			smallerC = largerC / consumers; // Smaller work remainder after work divided evenly
			largerC = largerC / (consumers - smallerC);
		}else {
			largerC /= consumers;
		}
		Buffer buff = new Buffer(bufferSize);	// Initialize buffer
		Producer[] producer = new Producer[producers];	// Declare Producer[] Array
		Consumer[] consumer = new Consumer[consumers];	// Declare Consumer[] Array

		// Initialize and run Producer[] and Consumer[] array's
		initP(producer, producers, smallerP, largerP, buff, seed);
		initC(consumer, consumers, smallerC, largerC, buff);

		// join producers and consumers
		joinP(producer, producers);
		joinC(consumer, consumers);

		// Use producerSum and consumerSum to keep track of checkSums
		int producerSum = 0; int consumerSum = 0;
		// Use producerWork and consumerWork to keep track of work/count of objects
		int producerWork = 0; int consumerWork = 0;
		// Get numbers for above created variables for printing
		for(int i = 0; i < producers; i++){
			producerSum += producer[i].getCheckSum();
			producerWork += producer[i].getWork();
		}
		for(int i = 0; i < consumers; i++){
			consumerSum += consumer[i].getCheckSum();
			consumerWork += consumer[i].getWork();
		}

		// Final string to print that producer's and consumer's are done
		String s = String.format("Producer(s): Finished producing %d items with checksum being %d\n", producerWork, producerSum);
		s += String.format("\033[0;4mConsumer(s): Finished consuming %d items with checksum being %d\033[0;0m\n", consumerWork, consumerSum);
		System.out.println("\n" + s);
	}
	
	// Each producer thread terminates when the specified number of items 
	// has been produced. The main/calling program should print a message like this:
	// Producer(s): Finished producing 18 items with checksum being 864
	
	// Each consumer thread terminates when the specified number of items
	// has been consumed. The main/calling program should print a message like this:
	// Consumer(s): Finished consuming 18 items with checksum being 864

	// Call this function from your producer or your consumer to get the time stamp to be displayed
	public static String getTime() {
		Clock offsetClock = Clock.offset(Clock.systemUTC(), Duration.ofHours(-9));
		Instant time = Instant.now(offsetClock);
		String timeString = time.toString();
		timeString = timeString.replace('T', ' ');
		timeString = timeString.replace('Z', ' ');
		return(timeString);
	}

	// Initialize and run Producer[]
	public static void initP(Producer[] producer, int producers, int smallerP, int largerP, Buffer buff, int seed){
		// Initialize and run Producer[] and Consumer[] array's
		for(int i = 0; i < producers; i++) {
			// Work can't be divided evenly, create last object with less work
			if(smallerP > 0 && i == producers - 1) {
				producer[i] = new Producer(buff, smallerP, i + 1, seed); 
			}else {
				// Create new object
				producer[i] = new Producer(buff, largerP, i + 1, seed);
			}
			// Run new object
			producer[i].start(); 
		}
	}

	// Initialize and run Consumer[]
	public static void initC(Consumer[] consumer, int consumers, int smallerC, int largerC, Buffer buff){
		for(int i = 0; i < consumers; i++) {
			// Work can't be divided evenly, create last object with less work
			if(smallerC > 0 && i == consumers - 1 ) {
				consumer[i] = new Consumer(buff, smallerC, i + 1); 
			}else {
				// Create new object
				consumer[i] = new Consumer(buff, largerC, i + 1);
			}
			// Run new object
			consumer[i].start();
		}
	}

	// .join() Producer[]'s objects
	public static void joinP(Producer[] producer, int producers){
		for(int i = 0; i < producers; i++){
			try {
				// producerSum += producer[i].getCheckSum();
				producer[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// .join() Consumers[]'s objects
	public static void joinC(Consumer[] consumer, int consumers){
		for(int i = 0; i < consumers; i++){
			try {
				// consumerSum += consumer[i].getCheckSum();
				consumer[i].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
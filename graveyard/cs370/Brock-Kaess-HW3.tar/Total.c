#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <ctype.h>
#include <stdlib.h>

/*
    Takes an int and returns a facotrial of sums for it
*/
int sum(int num){
    for(int i = num - 1; i > 0; i--){
        num += i;
    }
    return num;
}

int main(int argc, char *argv[]){
    if(argc < 2){
        fprintf(stderr, "%s -> ERROR: I need more arguments\n", argv[0]);
        exit(1);
    }
    char shm_Total[] = "Shared_Mem_Total";  // Name of shared mem seg
    int shm_fd_Total = shm_open(shm_Total, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    int SIZE = 32; // Byte size
    void *shmPtrTotal = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd_Total, 0); // Mapping the new mem seg


    int pid = getpid(), rtn = sum(atoi(argv[2]));
    printf("Total[%d] : Sum = %d\n", pid, rtn);
    sprintf(shmPtrTotal, "%d", rtn);
    shm_unlink(shm_Total);
    return rtn;
}
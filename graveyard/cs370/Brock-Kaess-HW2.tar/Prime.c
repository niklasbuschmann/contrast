#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int prime(int count){
    /* rtn is the last prime value we want to return for printing
        i is our rang of numbers from 0 to count.
        k is our number of primes found thus far.
        s is our prime checker.
    */
    int rtn = -1, i = 0, k = 0, s = 0;
    // Iterate 0-count finding count primes
    while(k < count){
        // Check for primeness
        for(s = 2; s <= i; s++){
            if(i % s == 0){
                break;
            }
        }
        // Prime and the right number?
        if(i == s){
            printf("%d, ", i);
            k++;
            rtn = i;
        }
        i++;
    }
    printf("\n");
    return rtn;
}

int main(int argc, char *argv[]){
    int pid = getpid();
    printf("Prime[%d]: The first %d prime numbers are: \n", pid, atoi(argv[1]));
    return prime(atoi(argv[1]));;
}
#include <stdio.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>

/* Use fopen() to read the string from the file. Input numbers are [1,25]. 
For ease of grading, your program must fork()/exec() the programs in 
this order for each Number: Fibb-Prime-Total.
*/
int main(int argc, char *argv[]){
    // Check we have enough args
    if(argc < 2){
        fprintf(stderr, "I need more arguments\n");
        exit(1);
    }
    // Create a pipe and fork a child process to execute CharacterReader, giving
    // it the .txt file as an argument. Wait for a return and read from the pipe.

    char charReadVals[16]; // C style string for CharacterReader return vals
     
    int fd[2];
    if(pipe(fd) == -1){ // Check pipe failure
        fprintf(stderr, "%s -> ERROR: Pipe failed.\n", argv[0]);
        exit(2);
    }
    int status;
    pid_t pid = getpid();
    pid_t cpid = fork();

    if(cpid < 0){ // ERROR
        fprintf(stderr, " -> ERROR: Fork failed.\n");
        exit(3);
    }else if(cpid == 0){ // Child process
        close(fd[0]);
        char msg[16];
        sprintf(msg, "%d", fd[1]);
        execlp("./CharacterReader", "CharacterReader", argv[1], msg, NULL);
        close(fd[1]);
    }else { // Parent process
        close(fd[1]); // close parent write end
        wait(&status);
    
        int count = read(fd[0], charReadVals, sizeof(charReadVals));
        charReadVals[count] = '\0';
        close(fd[0]);
        printf("Starter[%d]: contents read from the read end pipe: %s.\n", pid, charReadVals);
    }



    // Fibb shared mem
    char shm_Fibb[] = "Shared_Mem_Fib";  // Name of shared mem seg
    int shm_fd_Fibb = shm_open(shm_Fibb, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    int SIZE = 32;  // Byte size
    ftruncate(shm_fd_Fibb, SIZE); // Set byte ammount
    void *shmPtrFibb = mmap(0, SIZE, PROT_READ, MAP_SHARED, shm_fd_Fibb, 0); // Mapping the new mem seg
    // Prime shared mem
    char shm_Prime[] = "Shared_Mem_Prime";  // Name of shared mem seg
    int shm_fd_Prime = shm_open(shm_Prime, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    ftruncate(shm_fd_Prime, SIZE); // Set byte ammount
    void *shmPtrPrime = mmap(0, SIZE, PROT_READ, MAP_SHARED, shm_fd_Prime, 0); // Mapping the new mem seg
    // Total shared mem
    char shm_Total[] = "Shared_Mem_Total";  // Name of shared mem seg
    int shm_fd_Total = shm_open(shm_Total, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    ftruncate(shm_fd_Total, SIZE); // Set byte ammount
    void *shmPtrTotal = mmap(0, SIZE, PROT_READ, MAP_SHARED, shm_fd_Total, 0); // Mapping the new mem seg

    // Print our work
    printf("Starter[%d]: Created shared memory \"%s\" with FD: %d\n", pid, shm_Fibb, shm_fd_Fibb);
    printf("Starter[%d]: Created shared memory \"%s\" with FD: %d\n", pid, shm_Prime, shm_fd_Prime);
    printf("Starter[%d]: Created shared memory \"%s\" with FD: %d\n", pid, shm_Total, shm_fd_Total);

    // Make 2d array to store the shared mem name where
    // the the first column contains the file location 
    // and the second column contains the shared mem
    char *execLoop[3][2] = {
        {"./Fibb",shmPtrFibb}, 
        {"./Prime",shmPtrPrime}, 
        {"./Total",shmPtrTotal}
    };
    int rtnLoop[3];
    pid_t cpid0[3];
    for(int i = 0; i < 3; i++){
        cpid0[i] = fork();
        if(cpid0[i] < 0){
            fprintf(stderr, " -> ERROR: Fork failed.\n");
            exit(7);
        }else if(cpid0[i] == 0){
            execlp(execLoop[i][0], execLoop[i][0], execLoop[i][1], charReadVals, NULL);
        }
    }

    for(int i = 0; i < 3; i++){
        if(!(cpid0[i] < 0) && !(cpid0[i] == 0)){
            waitpid(cpid0[i], &status, WUNTRACED | WCONTINUED);
            rtnLoop[i] = atoi(execLoop[i][1]);
        }else{
            fprintf(stderr, " -> ERR0R: Unexpected Behaviour...\n");
        }
    }

    printf("Starter[%d]: Fibb last number: %d\n", pid, rtnLoop[0]);
    printf("Starter[%d]: Prime last number: %d\n", pid, rtnLoop[1]);
    printf("Starter[%d]: Total last number: %d\n", pid, rtnLoop[2]);
    return 0;
}
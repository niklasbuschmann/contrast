#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int fibBrooo(int num){
    int t1 = 0, t2 = 1, nextTerm = -1, rtn = -1;
    for (int i = 0; i < num; i++) {
        printf("%d", t1);
        if(i < num - 1){
            printf(", ");
        } else{
            rtn = t1;
        }
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
    printf("\n");
    return rtn;
}

int main(int argc, char *argv[]){
    int pid = getpid();
    printf("Fibb[%d]: Number of terms in fibonacii series is %d\n", pid, atoi(argv[1]));
    printf("Fibb[%d]: The first %d numbers of the Fibonacci sequence are: \n", pid, atoi(argv[1]));
    return fibBrooo(atoi(argv[1]));
}
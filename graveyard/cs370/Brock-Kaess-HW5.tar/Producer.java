import java.util.Random;

public class Producer extends java.lang.Thread {
	// Necessary variables and object declaration
	Buffer buff;	//Copy of the instance of the buffer to access in common with others
	int count;	 	// Number of elements the producer should generate
	int id;			// ID which is number of the producer thread (first producer = 1, second = 2...)
	Random randomWithSeed;	// Seed used by random number generator for insertion numbers
	int sum = 0;	// checksum of the items it has produced.
	int data;		// Data value pulled from buffer.
	int location;	// Location of Buffer consumed.
	int time;		// Time for print statement

	public Producer(Buffer buff, int count, int id, int seed) {
		// Assign values to the variables
		this.buff = buff;
		this.count = count;
		this.id = id;
		randomWithSeed = new Random(seed);
	}
	
	@Override
	public void run() {
		/* Your code goes in here
		*
		*
		*
		--->To generate a value between 0 (inclusive) and 99 (inclusive) using the seeded random  number generator use the following code
		--->          int variable = randomWithSeed.nextInt(100);
		*
		*
		*
		*/
		synchronized(buff) {
			for(int i = 0; i < count; i++) {
				data = randomWithSeed.nextInt(100);
				sum += data;
				location = buff.push(data);
				System.out.print(this.toString());
				System.out.flush();
			}
		}
	}
	
	// Returns the checksum of the items it has produced.
	public int getCheckSum(){
		return sum;
	}

	// Returns the value of work/count of things done
	public int getWork(){ return count; }
	
	// When a producer successfully inserts an item in the buffer it should print the location 
	// of insertion and time when insertion occurs with microsecond resolution, using this format:
	// Producer 1 inserted 62 at index 0 at time 2021-03-16 15:26:50.924314
	public String toString() {
		String s = String.format("Producer %3d produced %3d %3s %6s %d at time %s\n", id, data, "at", "index", location, Coordinator.getTime());
		return s;
	}
}

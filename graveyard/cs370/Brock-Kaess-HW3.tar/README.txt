README
======
This is a simple practical which in itself 
contains another practical! Files in the tar include:

-Starter.c 
-Fibb.c 
-Prime.c 
-Total.c 
-Makefile
-HW2README.txt (this file)
-hard work and tears with a bit of love

QUESTIONS
=========

1. Name the function that is used to create a pipe. 
Which ends denotes the read and the write ends of a pipe? (2 points)


2. Name the function used to map files or devices in to memory? (1 point)


3. Name the function used to open a shared memory object? 
What does it return? (2 points)

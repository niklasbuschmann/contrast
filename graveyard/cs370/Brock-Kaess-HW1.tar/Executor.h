//This is the Header file for the c file Executor
//Created by Brock Kaess

 int get_iteration_no(int rand);

 int get_arr_size(int rand);

 char get_arr_val(int rand);

 float ratio(char *arr, int size, int *maxCountPointer);

 double get_running_ratio();

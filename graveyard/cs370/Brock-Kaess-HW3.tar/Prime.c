#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <ctype.h>
#include <stdlib.h>

int prime(int count){
    /* rtn is the last prime value we want to return for printing
        i is our rang of numbers from 0 to count.
        k is our number of primes found thus far.
        s is our prime checker.
    */
    int rtn = -1, i = 0, k = 0, s = 0;
    // Iterate 0-count finding count primes
    while(k < count){
        // Check for primeness
        for(s = 2; s <= i; s++){
            if(i % s == 0){
                break;
            }
        }
        // Prime and the right number?
        if(i == s){
            printf("%d", i);
            if(k < count - 1){
                printf(", ");
            }
            k++;
            rtn = i;
        }
        i++;
    }
    printf("\n");
    return rtn;
}

int main(int argc, char *argv[]){
    if(argc < 2){
        fprintf(stderr, "%s -> ERROR: I need more arguments\n", argv[0]);
        exit(1);
    }
    char shm_Prime[] = "Shared_Mem_Prime";  // Name of shared mem seg
    int shm_fd_Prime = shm_open(shm_Prime, O_CREAT | O_RDWR, 0666); // Make/open mem seg
    int SIZE = 32;  // Byte size
    void *shmPtrPrime = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd_Prime, 0); // Mapping the new mem seg


    int pid = getpid();
    printf("Prime[%d]: The first %d prime numbers are: \n", pid, atoi(argv[2]));
    int rtn = prime(atoi(argv[2]));
    sprintf(shmPtrPrime, "%d", rtn);
    shm_unlink(shm_Prime);
    return rtn;
}
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <ctype.h>
#include <stdlib.h>

/*
    This executable reads a line at a time and keeps a
    running total of the numbers from each line to return.op0
*/
int main(int argc, char *argv[]){
    // Check we have enough args
    if(argc < 2){
        fprintf(stderr, " -> ERROR: I need more arguments\n");
        exit(1);
    }
   
    int fd = atoi(argv[2]);
    char msg[32];
    int counter = 0;
    // Parse each line's numbers and keep a running total of them.
    // Read char's from the file
    FILE *f = fopen(argv[1], "r");
    if(f == NULL){
        fprintf(stderr, " -> ERROR: empty file");
        exit(2);
    }
    char c[32];
    while(fgets(c, sizeof(c), f) != NULL){
        counter += atoi(c);
    }

    sprintf(msg, "%d", counter);
    write(fd, msg, strlen(msg) + 1);
    close(fd); // Close child write
    fclose(f);

    return 0;
}

public class Buffer {
	// Implement this as a Circular Buffer that satisfies the FIFO.
	int head = 0;		// First element in the list
	int tail = -1;		// Last element in the list
	int size = 0;		// Buffer size
	int capacity = 0; 	// Buffer capacity
	int[] buffer;		// Buffer
	
	
	public Buffer(int capacity) {
		// Assign values to the variables
		buffer = new int[capacity];
		this.capacity = capacity;
	}
	
	// Add element n to the buffer, return index added
	public int push(int n) {
		while(isFull()) {	// Array is full
			try {
				wait();	// Wait for consumer to pop
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int index = (tail + 1) % capacity; // Index to insert at
		buffer[index] = n;
		// Adjust size and tail
		size++;
		tail++;
		notify();
		return index;
	}
	
	// Remove element from buffer
	public int pop() {
		while(isEmpty()) { // Array already empty
			try {
				wait();	// Wait for producer to push
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int index = head % capacity; // Index to remove
		int n = buffer[index];
		// Adjust size and head, return popped element
		size--;
		head++;
		notify();
		return n;
	}
	
	// Getter to check if buffer is empty
	public boolean isEmpty() { return size == 0; }
	
	// Getter to check if buffer is full
	public boolean isFull(){ return size == capacity; }
	
	// Getter for buffer size
	public int size() { return size; }
}
